# Atlas User & Product Management API

FastAPI backend with MongoDB Atlas integration, Docker support, and REST APIs.

## Features
- User Management APIs
- Product Management APIs
- MongoDB Atlas connection
- Docker containerization
- Swagger UI support

## Run locally
pip install -r requirements.txt
uvicorn app.main:app --reload

## Run with Docker
docker build -t atlas-api .
docker run -p 8000:8000 atlas-api

Open:
http://localhost:8000/docs
