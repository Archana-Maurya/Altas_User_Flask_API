from pymongo import MongoClient

MONGO_URL = "mongodb+srv://archanamaurya382003:Archna123@motherline.nlvkz7u.mongodb.net/?appName=MotherLine"

client = MongoClient(MONGO_URL)

db = client["atlas_db"]

users_collection = db["users"]
products_collection = db["products"]
