from fastapi import FastAPI, HTTPException
from app.database import users_collection, products_collection
from app.schemas import UserCreate, UserResponse, ProductCreate, ProductResponse

app = FastAPI()

# ---------------- USERS ---------------- #

@app.post("/users")
def create_user(user: UserCreate):

    try:
        # convert to dict
        user_dict = user.dict()

        # insert into MongoDB
        result = users_collection.insert_one(user_dict)

        # add id to response
        user_dict["_id"] = str(result.inserted_id)

        return user_dict

    except Exception as e:
        return {"error": str(e)}

@app.get("/users/{email}", response_model=UserResponse)
def get_user(email: str):

    user = users_collection.find_one({"email": email})

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return {
        "name": user["name"],
        "email": user["email"],
        "phone": user.get("phone"),
        "address": user.get("address")
    }


# ---------------- PRODUCTS ---------------- #

@app.post("/products", response_model=ProductResponse)
def create_product(product: ProductCreate):

    existing = products_collection.find_one({"sku": product.sku})

    if existing:
        raise HTTPException(status_code=400, detail="SKU already exists")

    product_dict = product.dict()

    products_collection.insert_one(product_dict)

    return product_dict


@app.get("/products/{sku}", response_model=ProductResponse)
def get_product(sku: str):

    product = products_collection.find_one({"sku": sku})

    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    return {
        "sku": product["sku"],
        "name": product["name"],
        "price": product["price"],
        "stock": product["stock"],
        "description": product.get("description")
    }
# GET ALL USERS
@app.get("/users")
def get_all_users():
    users = []
    for user in users_collection.find():
        users.append({
            "name": user["name"],
            "email": user["email"],
            "phone": user["phone"],
            "address": user["address"]
        })
    return users


# UPDATE USER
@app.put("/users/{email}")
def update_user(email: str, user: UserCreate):
    result = users_collection.update_one(
        {"email": email},
        {"$set": user.dict()}
    )

    if result.modified_count == 0:
        return {"message": "User not found"}

    return {"message": "User updated successfully"}


# DELETE USER
@app.delete("/users/{email}")
def delete_user(email: str):
    result = users_collection.delete_one({"email": email})

    if result.deleted_count == 0:
        return {"message": "User not found"}

    return {"message": "User deleted successfully"}